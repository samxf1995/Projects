# Lab1
--------
1. Clone repository using git clone
2. Go to the repository's folder
3. Create the environment:
```
conda env create --force -f environment.yml
```
4. Activate the environment:
```
activate mie451-assignment-ir
```
5. Run Jupyter notebook:
```
jupyter notebook
```
